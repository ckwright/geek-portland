<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
<head profile="http://www.w3.org/2005/10/profile">
<title><?php echo $calendar_title ?></title>
<link rel="icon" 
      type="image/png" 
      href="http://www.geekportland.com/GPfavicon.ico">
<link rel="image_src" href="http://www.geekportland.com/images/geekportland_link.jpg" />

<link rel="stylesheet" type="text/css" href="../css/supercali.css">

<body>
<div class="top">
<a href="http://www.geekportland.com/"><div style="width:600px;height:125px;"> </div></a>
<div class="top_nav">
<a href="http://www.facebook.com/geekportland"><img src="/images/fb.png" /></a> <a href="https://twitter.com/#!/geekportland"><img src="/images/tw.png" /></a>
</div>
</div>
<div class="nav">
<br />
</div>
<div class="content">
    
<div align="center"><iframe src="https://spreadsheets.google.com/spreadsheet/embeddedform?formkey=dERtZUJaTjBNNkJjeFp2T1dzU3A0d1E6MQ" width="760" height="1500" frameborder="0" marginheight="0" marginwidth="0">Loading...</iframe></div>

</div>
<div class="bottom">
<p> </p>
</div>
</body>
</html>