<?php
/*
Supercali Event Calendar

Copyright 2006 Dana C. Hutchins

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

For further information visit:
http://supercali.inforest.com/
*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
<head profile="http://www.w3.org/2005/10/profile">
<title><?php echo $calendar_title ?></title>
<link rel="image_src" href="http://www.geekportland.com/images/geekportland_link.jpg" />
<link rel="icon" 
      type="image/png" 
      href="http://www.geekportland.com/GPfavicon.ico">

<link rel="stylesheet" type="text/css" href="css/supercali.css">
<?php if ($_REQUEST["size"] == "small") echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"css/small.css\">\n"; ?>
<?php if ($css) echo $css; ?>


<script language="JavaScript" src="js/CalendarPopup.js"></script>
<script language="JavaScript">document.write(getCalendarStyles());</script>
<script language="JavaScript" src="js/ColorPicker2.js"></script>
<script language="JavaScript" src="js/miscfunctions.js"></script>
<?php if ($javascript) echo $javascript; ?>


<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-7668669-2']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

</head>

<body>
<div class="top">
<div class="top_nav">
<?php 
if ($_REQUEST["size"] == "small") {
	echo "<a href=\"javascript:self.close()\" target=\"_self\">".$lang["close_window"]."</a>\n";
} else { 
	include "includes/top_nav.php";
}

?><br />
<a href="http://www.facebook.com/geekportland"><img src="/images/fb.png" /></a> <a href="https://twitter.com/#!/geekportland"><img src="/images/tw.png" /></a>
</div>
<!--<h4><?php echo $calendar_title; ?></h4>
<h1><?php echo $page_title; ?></h1>-->
</div>
<div class="nav">
<?php include "includes/nav.php"; ?>
</div>
<div class="content">
<?php if ($msg) echo "<p class=\"warning\">".$msg."</p>\n"; ?>