<input type="hidden" name="o" value="<?php echo $o; ?>">
<input type="hidden" name="c" value="<?php echo $c; ?>">
<input type="hidden" name="m" value="<?php echo $m; ?>">
<input type="hidden" name="a" value="<?php echo $a; ?>">
<input type="hidden" name="y" value="<?php echo $y; ?>">
<input type="hidden" name="w" value="<?php echo $w; ?>">